import java.util.Scanner;
class Main {
  public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        String[] questions = {"1) Which date on this timeline (see Figure 1) represents the beginning of a permanent British presence in North America?\nA 1565\nB 1587\nC 1607\nD 1620",
        "2) Which colony was established as a business venture?\nF Connecticut\nG Massachusetts\nH Georgia\nJ Virginia", 
        "3) The initial French exploration of North America resulted in â€”\nA economic colonies in Florida\nB competition with Spanish settlers\nC plantations using slave labor\nD cooperation with native groups",
        "4) The Treaty of Alliance of 1778 was signed by the United States and â€”\nF Spain\nG Portugal\nH Russia\nJ France",
        "5)  Which factor contributed to colonial victory in the American Revolution?\nA Shortages of British troops\nB Disloyalty of British generals\nC Lack of British popular support\nD Weakness of the British Navy",
        "6) Which document directly influenced the first ten amendments to the Constitution of the United States?\nF Mayflower Compact\nG Virginia Declaration of Rights\nH Articles of Confederation\nJ Emancipation Proclamation",
        "7) This statement (see Figure 2) was issued by the Continental Congress because the British government did not allow â€”\nA colonial businesses to support royal taxes\nB powers of the colonial legislatures to increase\nC colonists to have representation in Parliament\nD laws passed by Parliament to govern the colonies",
        "8) Which issue led to the development of the first political parties in the United States?\nF Abolition of slavery\nG Womenâ€™s suffrage\nH Expansion of western territories\nJ National governmentâ€™s powers",
        "9) Critics of Andrew Jacksonâ€™s stand on the Second Bank of the United States accused him of abusing executive powers by â€”\nA ignoring the contributions of political supporters\nB using the military against the Cherokee Nation\nC using the presidential veto to overrule Congress\nD opposing federal funding of internal improvements",
        "10) Which effect of the Civil War on the South is illustrated by this photograph? (see Figure 3)\nF Industrial pollution\nG Economic devastation\nH Political corruption\nJ Agricultural destruction",
        "11) Uprisings led by Nat Turner and Gabriel Prosser contributed to the Southern statesâ€™ decisions to â€”\nA pass harsh fugitive slave laws\nB accept the Missouri Compromise\nC enact Jim Crow legislation\nD support the passing of higher tariffs",
        "12) In the Gettysburg Address, President Abraham Lincoln rejected the idea that the country was â€”\nF a federation of sovereign states\nG a society based on equality\nH committed to unity at any cost\nJ founded on democratic ideals",
        "13) The Battle of Gettysburg was a significant event of the Civil War because it â€”\nA caused states to secede from the Union\nB was the opening conflict of the war\nC forced the surrender of the South\nD was the turning point of the war",
        "14) Which group helped Andrew Jackson become President of the United States the first time they could participate in an election?\nF People allowed to vote without paying a poll tax\nG Newly freed slaves from West Africa\nH People allowed to vote without owning property\nJ Naturalized immigrants from Eastern Europe",
        "15) Which man was a United States Senator who became the leader of the Confederacy?\nA Robert E. Lee\nB Jefferson Davis\nC Nat Turner\nD Stonewall Jackson",
        "16) This statement (see Figure 4) expressed President Lincolnâ€™s plans for â€”\nF creating a strategy for a Union victory\nG eliminating Jim Crow laws\nH convincing Congress to abolish slavery\nJ readmitting the Confederate states",
        "17) One major economic impact of the Civil War was the â€”\nA emergence of the South as a manufacturing center\nB increase in the number of laborers relocating to the South\nC strengthening of the North and Midwest industrial regions\nD increase in tariffs imposed on French and British goods",
        "18) The Great Migration of the early 20th century refers to the movement of â€”\nF European immigrants to western cities\nG European immigrants to northeastern cities\nH African Americans from the South to northern cities\nJ African Americans from the Midwest to eastern cities",
        "19) Which individual helped found the National Association for the Advancement of Colored People (NAACP)?\nA James Meredith\nB W.E.B. DuBois\nC Thurgood Marshall\nD Booker T. Washington",
        "20) During World War II, the purpose of posters such as this (see Figure 5) was to â€”\nF motivate American women to enter the work force in defense factories\nG encourage civilians to become members of the armed forces\nH show how Americans on the home front could contribute to the war effort\nJ pressure industries to dedicate their resources to war manufacturing",
        "21) Which economic factor completes this diagram? (see Figure 6)\nA Laissez-faire Policies\nB High Interest Rates\nC Low Consumer Demands\nD Strict Price Controls",
        "22) This event (see Figure 7) was a result of the passage of the â€”\nF Interstate Commerce Act\nG 17th Amendment\nH Sherman Antitrust Act\nJ 19th Amendment",
        "23) During the Industrial Revolution, new technology affected the economy of the United States by â€”\nA increasing worker productivity\nB limiting profits\nC decreasing urban population\nD generating tax revenues",
        "24) During World War II, which action was an example of this code of behavior? (see Figure 8)\nF Japanese civilians welcoming Allied troops\nG Japanese captors treating American POWs humanely\nH Japanese emperor accepting the terms of unconditional surrender\nJ Japanese troops committing suicide rather than surrendering",
        "25) The members of the World War II Nisei regiment were primarily â€”\nA Mexican Americans\nB Japanese Americans\nC German Americans\nD Italian Americans",
        "26) The Lend-Lease Act was passed by the United States Congress in response to increased â€”\nF concern about German aggression in Europe\nG anger over the Japanese invasion of China\nH concern about Italian demands in North Africa\nJ fear over the German pact with the Soviet Union",
        "27) During World War II, the role of the Selective Service System in the United States was to â€”\nA draft military personnel\nB ration manufactured goods\nC increase industrial productivity\nD replace factory workers",
        "28) Which effect did United States participation in World War II have on the home front?\nF An increase in volunteers for the war effort\nG The end of racial segregation in the South\nH A decline in farm income due to war rationing\nJ The growth of isolationism in the Midwest",
        "29) The United States interned many Japanese Americans during World War II because of â€”\nA their refusal to be deported\nB a fear they would aid the enemy\nC a concern over violent protest from them\nD their refusal to be drafted into the military",
        "30) The United States failed to join the League of Nations because â€”\nF the President vetoed the treaty\nG membership was restricted to European countries\nH the Senate rejected the treaty\nJ membership was limited by European leaders",
        "31) This document (see Figure 9) describes the United Statesâ€™ response to the â€”\nA Cold War tension in Europe\nB Japanese invasion of China\nC creation of the state of Israel\nD creation of the Manhattan Project",
        "32) Which president is most closely associated with the policy of massive retaliation?\nF Dwight D. Eisenhower\nG John F. Kennedy\nH Lyndon Johnson\nJ Richard Nixon",
        "33) This headline (see Figure 10) describes the result of the increased fear of â€”\nA communist infiltration\nB political corruption\nC organized crime\nD nuclear energy",
        "34) This practice (see Figure 11) was outlawed with the passage of the â€”\nF 15th Amendment\nG Civil Rights Act of 1964\nH 19th Amendment\nJ Voting Rights Act of 1965",
        "35) The North Atlantic Treaty Organization was created primarily to â€”\nA protect Western Europe from communism\nB encourage communist factions in China\nC install democratic governments in Africa\nD protect South America from invasion",
        "36) Veterans of which war often faced public hostility when they returned from duty?\nF World War I\nG World War II\nH Korean War\nJ Vietnam War",
        "37) Over the last three decades, the American work force has had to acquire and improve skills in â€”\nA computer technology\nB automobile repair\nC heavy machinery\nD medical equipment",
        "38) Modern American schools adapted to serve new immigrants in the United States by â€”\nF limiting vocational programs\nG offering bilingual education\nH offering extracurricular activities\nJ requiring physical education",
        "39) Which President was in office during the Cold War?\nA Woodrow Wilson\nB Franklin D. Roosevelt\nC John F. Kennedy\nD William Clinton",
        "40) In which area did this conflict occur? (see Figure 12)\nF Afghanistan border\nG Indochinese Peninsula\nH Former Yugoslavia\nJ Persian Gulf",
        "41) Which innovation best completes this diagram? (see Figure 13)\nA Radio\nB Newspaper\nC Satellite dish\nD Compact disc",
        "42) Which conclusion can be drawn from the information in these graphs? (see Figure 14)\nF Family income has little bearing on access to computers.\nG Access to education improves with higher family income.\nH Schools narrow the technological gap caused by income.\nJ There are more children born in higher-income families.",
        "43) Which type of action is described by this quotation? (see Figure 15)\nA Independent investigations\nB Diplomatic relations\nC Economic sanctions\nD Strategic attacks",
        "44) The land area located between 80Â°W and 90Â°W and 25Â°N and 30Â°N (see Figure 16) represents the acquisition of â€”\nF land won through the French and Indian War\nG territories according to the Northwest Ordinance\nH land as a result of the Revolutionary War\nJ Florida through a treaty with Spain",
        "45) Which event best completes this sequence? (see Figure 17)\nA Confederate attack on Fort Sumter\nB Independence gained from Mexico\nC Purchase of the Louisiana Territory\nD Completion of the Transcontinental Railroad",
        "46) The family shown in this picture (see Figure 18) is most likely on the way to â€”\nF find factory work in the Northeast\nG claim a homestead in the West\nH work as indentured servants in Virginia\nJ prospect for gold in California",
        "47) President William Howard Taft developed the Dollar Diplomacy policy to support â€”\nA United States citizens traveling to Europe\nB equal trading rights in Japan\nC United States businesses investing in Latin America\nD trade with the Philippines",
        "48) By the late 1890s, many American business leaders believed their best chance for future growth depended on â€”\nF tighter governmental regulation\nG the increasing growth of labor unions\nH laws abolishing the use of child labor\nJ the establishment of foreign markets",
        "49) Which country completes this table? (see Figure 19)\nA Japan\nB Poland\nC France\nD China",
        "50) Which phrase best completes this diagram? (see Figure 20)\nF Rise of Fascism\nG Communist Control\nH Rapid Rearmament\nJ Formation of Democracy",
        "51) The town meetings held by colonists in buildings such as this one (see Figure 21) were important because they demonstrated a form of â€”\nA religious toleration\nB direct democracy\nC multicultural integration\nD representative government",
        "52) The different types of economies found in the original colonies were primarily a reflection of the â€”\nF nationalities of the settlers\nG geography of the areas\nH provisions of the charters\nJ religion of the settlers",
        "53) John Lockeâ€™s ideas contributed to the Declaration of Independence because he influenced the belief in â€”\nA capitalism and free enterprise\nB self-government and natural rights\nC a strong federal government and rule of law\nD a monarchy and democracy",
        "54) What is the correct order for these events? (see Figure 22)\nF 1, 3, 4, 2\nG 2, 4, 3, 1\nH 3, 2, 1, 4\nJ 4, 1, 2, 3",
        "55) Which part of the national government controls the supply of money in the economy?\nA Congress\nB Treasury Department\nC President\nD Federal Reserve",
        "56) Which New Deal program attempted to protect Americans from the instability of banks during the Great Depression?\nF Works Progress Administration\nG Tennessee Valley Authority\nH Federal Deposit Insurance Corporation\nJ Agricultural Adjustment Administration",
        "57) What failed to carry out the ideals expressed in the Declaration of Independence?\nA Bill of Rights\nB Dred Scott decision\nC 14th Amendment\nD Voting Rights Act of 1965",
        "58) How did the Great Awakening most influence the American Revolutionary movement?\nF It supported the practice of slave labor.\nG It established official state religions.\nH It challenged the established government order.\nJ It discouraged trade with foreign countries.",
        "59) Which principle is shared by the Articles of Confederation and the Constitution of the United States?\nA Judicial review\nB Limited government\nC Separation of powers\nD Checks and balances",
        "60) Which Supreme Court decision includes this quotation? (see Figure 23)\nF Marbury v. Madison\nG Cohens v. Virginia\nH Gibbons v. Ogden\nJ McCulloch v. Maryland"};
        int correct = 0;
        String[] answerkey = {"C","J","D","J","C","G","C","J","C","G","A","F","D","H","B","J","C","H","B","H","A","H","A","J","B","F","A","F","B","H","A","F","A","J","A","J","A","G","C","J","C","H","B","J","B","G","C","J","A","G","B","G","B","H","D","H","B","H","B","F"};
        int[] score = {0, 204, 236, 256, 270, 282, 291, 300, 307, 314, 320, 326, 331, 336, 341, 346, 350, 354, 358, 362, 366, 370, 374, 378, 381, 385, 388, 392, 395, 399, 402, 406, 409, 413, 416, 420, 423,427, 431, 434, 438, 442, 446, 450, 454, 459, 463, 468, 473, 478, 484, 490, 497, 504, 512, 522, 533, 547, 567, 600, 600};
        
        System.out.println("Use this URL to refer to Figures throughout the test: https://drive.google.com/file/d/1_XuzdPfpeMrz-z4NFnTqNodJvm-Fi2db/view?usp=sharing ");
        
        for(int i=0;i<questions.length;i++){
            System.out.println(questions[i]);
            String answer = scan.nextLine();
            if(answer.equals(answerkey[i])||answer.equals(answerkey[i].toLowerCase())){
                System.out.println("correct");
                correct++;
            }else{
                System.out.println("wrong");
            }
        }//questions 
     
        if (correct < 30){
          System.out.println("you got score "+score[correct]+" you didnt pass");
        }else if(correct>=30 && correct<53){
            System.out.println("you got score "+score[correct]+" you passed");
        }else if(correct>=53){
            System.out.println("you got score "+score[correct]+" you passed advanced");
        }//calculate score
    }//main
}//class